// Temperature has a default value of 50 degrees
// Humidity has a default value of 40%